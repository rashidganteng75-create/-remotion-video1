import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame} from 'remotion';
import {BEAT6, FPS, T_CLOSE, T_TITLE} from './timing';
import {Bulb, Cam, City, Cube, Defs, L, Magnifier, Person, Pill, Q, Sky, Sparkle, TaskCard, cityPt, fontFamily, mix, pt} from './lib';

export type SP = {dur: number; from: number};
const svgProps = {width: 1080, height: 1920, viewBox: '0 0 1080 1920', style: {position: 'absolute' as const}};
const U = 60;

// ---------- ruang belajar ----------
const PY: React.FC<{y: number; x0: number; x1: number; z0: number; z1: number; fill: string; op?: number}> = ({y, x0, x1, z0, z1, fill, op = 1}) => (
  <polygon points={Q([[x0, y, z0], [x1, y, z0], [x1, y, z1], [x0, y, z1]], U)} fill={fill} opacity={op} />
);
const LN: React.FC<{y: number; xa: number; xb: number; z: number; w?: number; c: string; op?: number}> = ({y, xa, xb, z, w = 6, c, op = 1}) => (
  <polyline points={Q([[xa, y, z], [xb, y, z]], U)} stroke={c} strokeWidth={w} strokeLinecap="round" opacity={op} fill="none" />
);
const Room: React.FC<{mood: number; monitor?: boolean}> = ({mood, monitor}) => (
  <g>
    <Cube x={-5} y={-4} z={-0.4} w={10} d={8} h={0.4} c={mix('#6a5fc4', '#cdbfff', mood)} u={U} />
    <Cube x={-5} y={-4} w={10} d={0.25} h={6} c={mix('#4b4fa3', '#dfe8ff', mood)} u={U} />
    <Cube x={-5} y={-4} w={0.25} d={8} h={6} c={mix('#5a4fb0', '#efe6ff', mood)} u={U} />
    {!monitor && (
      <g>
        <PY y={-3.75} x0={-1.6} x1={1.6} z0={2.4} z1={5.2} fill={mix('#1b1f4b', '#bfe0ff', mood)} />
        <LN y={-3.74} xa={-1.6} xb={1.6} z={3.8} c="#fff" w={5} />
        <polyline points={Q([[0, -3.74, 2.4], [0, -3.74, 5.2]], U)} stroke="#fff" strokeWidth={5} />
      </g>
    )}
  </g>
);
const Desk: React.FC = () => (
  <g>
    {[[-2.1, -1.1], [1.9, -1.1], [-2.1, 1.0], [1.9, 1.0]].map(([x, y], i) => (<Cube key={i} x={x} y={y} w={0.2} d={0.2} h={1.5} c="#e9d5c0" u={U} />))}
    <Cube x={-2.2} y={-1.2} z={1.5} w={4.4} d={2.4} h={0.18} c="#fff1e0" u={U} />
  </g>
);
const LY = -0.59;
const Laptop: React.FC<{glow: number; children?: React.ReactNode}> = ({glow, children}) => (
  <g>
    <Cube x={-0.7} y={-0.6} z={1.68} w={1.5} d={1} h={0.07} c="#e8ecff" u={U} />
    <PY y={-0.6} x0={-0.7} x1={0.8} z0={1.75} z1={2.95} fill="#2c2a5a" />
    <PY y={LY} x0={-0.6} x1={0.7} z0={1.85} z1={2.85} fill={mix('#3b4aa8', '#8ec5ff', glow)} />
    {children}
  </g>
);
const LAP: [number, number] = [540 + pt(0.05, LY, 2.35, U)[0], 1000 + pt(0.05, LY, 2.35, U)[1]];
const PP = pt(3.4, 0.4, 0, U);
const Wrap: React.FC<{children: React.ReactNode}> = ({children}) => <g transform="translate(540,1000)">{children}</g>;

// ---------- 1. HOOK ----------
export const S1: React.FC<SP> = ({dur}) => {
  const f = useCurrentFrame();
  const u = 28;
  const src = [[2, 2], [20, 4], [6, 18], [24, 22], [14, 10], [10, 26]].map(([x, y]) => {const p = cityPt(x, y, 5, u); return [540 + p[0], 640 + p[1]];});
  const folks = [[8, 12, '#b9a3ff'], [20, 16, '#ffb36b'], [12, 24, '#8ec5ff'], [24, 8, '#d9ccff']] as const;
  return (
    <AbsoluteFill>
      <Sky mood={0} f={f} />
      <svg {...svgProps}>
        <Defs />
        <Cam f={f} dur={dur} a={[0.85, 0, -40]} b={[1.25, 0, 60]}>
          <g transform="translate(540,640)"><City f={f} mood={0} u={u} /></g>
          {folks.map(([x, y, c], i) => {const p = cityPt(x, y, 0.05, u); return <Person key={i} x={540 + p[0]} y={640 + p[1]} c={c} s={0.42} dev bob={Math.sin(f * 0.1 + i) * 1.5} />;})}
          {src.map((s, k) => (<line key={k} x1={s[0]} y1={s[1]} x2={540} y2={250} stroke="#9fd0ff" strokeWidth={3} strokeDasharray="8 10" strokeDashoffset={-f * 2} opacity={0.35} />))}
          <circle cx={540} cy={250} r={150 + Math.sin(f * 0.1) * 10} fill="url(#glowB)" />
          <circle cx={540} cy={250} r={46} fill="#e9f3ff" />
          <Sparkle x={540} y={250} r={30} c="#8ec5ff" rot={f * 1.5} />
          {src.map((s, k) => {
            const p = ((f + k * 14) % 84) / 84;
            const e = Easing.inOut(Easing.cubic)(p);
            return <TaskCard key={k} x={s[0] + (540 - s[0]) * e} y={s[1] + (250 - s[1]) * e - Math.sin(p * Math.PI) * 60} s={0.65 - 0.4 * e} op={Math.min(1, p * 6) * (1 - Math.max(0, (p - 0.85) / 0.15))} />;
          })}
        </Cam>
        <text x={540} y={640} textAnchor="middle" fontFamily={fontFamily} fontWeight={800} fontSize={340 + Math.sin(f * 0.15) * 12} fill="#fff" opacity={L(f, dur * 0.55, dur * 0.55 + 20, 0, 0.9)} style={{filter: 'drop-shadow(0 0 30px #ffb36b)'}}>?</text>
      </svg>
    </AbsoluteFill>
  );
};

// ---------- 2. KETERGANTUNGAN ----------
export const S2: React.FC<SP> = ({dur}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Sky mood={0.1} f={f} />
      <svg {...svgProps}>
        <Defs />
        <Cam f={f} dur={dur} a={[1, 0, 0]} b={[1.18, -40, -60]}>
          <Wrap>
            <Room mood={0.1} />
            <Desk />
            <Laptop glow={L(f, 0, dur, 0.4, 1)}>
              {[0, 1, 2, 3, 4].map((i) => (<LN key={i} y={LY + 0.01} xa={-0.5} xb={-0.5 + 1.0 * L((f + i * 7) % 40, 0, 40, 0.1, 1)} z={2.7 - i * 0.18} c="#fff" w={5} op={0.9} />))}
            </Laptop>
            <Person x={PP[0]} y={PP[1]} c="#b9a3ff" s={1.35} sit bob={Math.sin(f * 0.1) * 2} />
          </Wrap>
          <circle cx={LAP[0]} cy={LAP[1]} r={L(f, 0, dur, 60, 220)} fill="url(#glowB)" opacity={0.6} />
          {[0, 1, 2, 3, 4].map((k) => {
            const p = ((f + k * 18) % 90) / 90;
            const e = Easing.inOut(Easing.cubic)(p);
            const sx = 1020, sy = 430 + k * 90;
            return <TaskCard key={k} x={sx + (LAP[0] - sx) * e} y={sy + (LAP[1] - sy) * e} s={1.1 - 0.7 * e} op={Math.min(1, p * 8) * (1 - Math.max(0, (p - 0.85) / 0.15))} rot={-8 * e} />;
          })}
          <Sparkle x={LAP[0] - 20} y={LAP[1] - 210} r={34} c="#8ec5ff" rot={f * 2} />
          <Bulb x={PP[0] + 540} y={PP[1] + 1000 - 270} s={L(f, 0, dur, 1, 0.55)} on={L(f, 0, dur, 1, 0.12)} />
        </Cam>
      </svg>
    </AbsoluteFill>
  );
};

// ---------- 3. KEHILANGAN KESEMPATAN BELAJAR ----------
export const S3: React.FC<SP> = ({dur}) => {
  const f = useCurrentFrame();
  const flick = Math.sin(f * 0.35) > 0.93 ? 0.35 : 0.06;
  const words = ['berpikir', 'mencoba', 'belajar'];
  const sp = pt(1.3, 0.5, 1.9, U);
  const lift = 0.1 + 0.18 * Math.sin(f * 0.12);
  return (
    <AbsoluteFill>
      <Sky mood={0.25} f={f} />
      <svg {...svgProps}>
        <Defs />
        <Cam f={f} dur={dur} a={[1.05, 0, 0]} b={[1.25, -60, -80]}>
          <Wrap>
            <Room mood={0.25} />
            <Desk />
            <Laptop glow={0.3} />
            {/* buku terbuka */}
            <polygon points={Q([[-1.9, 0.1, 1.7], [-1.15, 0.1, 1.7], [-1.15, 1.0, 1.7], [-1.9, 1.0, 1.7]], U)} fill="#fff" />
            <polygon points={Q([[-1.1, 0.1, 1.7], [-0.35, 0.1, 1.7 + lift], [-0.35, 1.0, 1.7 + lift], [-1.1, 1.0, 1.7]], U)} fill="#f4eeff" />
            {[0.3, 0.5, 0.7].map((y, i) => (<polyline key={i} points={Q([[-1.8, y, 1.71], [-1.25, y, 1.71]], U)} stroke="#b9a3ff" strokeWidth={4} strokeLinecap="round" />))}
            <Cube x={0.9} y={0.1} z={1.68} w={1.0} d={0.8} h={0.03} c="#ffffff" u={U} />
            {/* benih ide yang belum tumbuh */}
            <g transform={`translate(${sp[0]},${sp[1]}) scale(${0.9 + 0.08 * Math.sin(f * 0.1)})`}>
              <circle r={22} fill="none" stroke="#fff" strokeDasharray="5 6" opacity={0.7} />
              <path d="M0 14 L0 -2 M0 4 Q-12 -4 -14 -12 M0 0 Q10 -6 12 -14" stroke="#9be3b0" strokeWidth={4} fill="none" strokeLinecap="round" />
            </g>
            <Person x={PP[0]} y={PP[1]} c="#b9a3ff" s={1.35} sit rot={Math.sin(f * 0.05) * 3} bob={Math.sin(f * 0.07) * 2} />
          </Wrap>
          <Bulb x={PP[0] + 540} y={PP[1] + 1000 - 280} s={1.1} on={flick} />
          {words.map((w, i) => {
            const p = Math.min(1, Math.max(0, (f - 15 - i * 28) / 110));
            return <Pill key={w} x={PP[0] + 540 - 160 - p * 160 + i * 40} y={PP[1] + 1000 - 330 - p * 260} t={w} bg="#8a78e8" s={0.8 + 0.2 * (1 - p)} op={Math.sin(p * Math.PI) * 0.95} />;
          })}
        </Cam>
      </svg>
    </AbsoluteFill>
  );
};

// ---------- 4. JAWABAN != PEMAHAMAN ----------
export const S4: React.FC<SP> = ({dur}) => {
  const f = useCurrentFrame();
  const n = Math.min(9, Math.floor(f / 6));
  const conf = L(f, dur * 0.42, dur * 0.55, 0, 1);
  const pp = pt(1.2, -0.6, 0, U);
  return (
    <AbsoluteFill>
      <Sky mood={0.2} f={f} />
      <svg {...svgProps}>
        <Defs />
        <Cam f={f} dur={dur} a={[1.0, 0, 20]} b={[1.2, 30, -20]}>
          <Wrap>
            <Room mood={0.2} monitor />
            <PY y={-3.75} x0={-3.1} x1={3.1} z0={1.9} z1={5.7} fill="#2c2a5a" />
            <PY y={-3.74} x0={-2.9} x1={2.9} z0={2.1} z1={5.5} fill="#3b4aa8" />
            {Array.from({length: n}).map((_, i) => {
              const z = 5.2 - i * 0.36;
              const c = pt(2.55, -3.73, z, U);
              return (
                <g key={i}>
                  <LN y={-3.73} xa={-2.6} xb={-2.6 + 3.2 - (i % 3) * 0.6} z={z} c="#cfe6ff" w={7} />
                  <circle cx={c[0]} cy={c[1]} r={9} fill="#9be3b0" />
                </g>
              );
            })}
            <Person x={pp[0]} y={pp[1]} c={conf > 0.5 ? '#ffb36b' : '#b9a3ff'} s={1.5} rot={conf * Math.sin(f * 0.25) * 10} bob={Math.sin(f * 0.08) * 2} />
            <Desk />
          </Wrap>
          {[0, 1, 2].map((i) => (
            <text key={i} x={540 + pp[0] - 50 + i * 50} y={1000 + pp[1] - 280 - Math.sin(f * 0.12 + i) * 14 - i * 20} fontFamily={fontFamily} fontWeight={800} fontSize={70} fill="#ffb36b" opacity={conf}>?</text>
          ))}
          <Bulb x={540 + pp[0] + 110} y={1000 + pp[1] - 250} s={0.9} on={0.05} />
        </Cam>
        <Pill x={300} y={300} t="JAWABAN ✓" bg="#6aa8f5" />
        <Pill x={780} y={300} t="PAHAM ?" bg={mix('#6a6aa0', '#ffb36b', conf)} op={0.5 + 0.5 * conf} />
      </svg>
    </AbsoluteFill>
  );
};

// ---------- 5. AI SEBAGAI ALAT BANTU ----------
export const S5: React.FC<SP> = ({dur}) => {
  const f = useCurrentFrame();
  const mood = L(f, 0, 45, 0.3, 1);
  const prog = L(f, 10, dur * 0.45, 0, 1);
  const wr = Array.from({length: 14}).map((_, i) => pt(1.05 + i * 0.062, 0.45 + Math.sin(i * 1.3) * 0.12, 1.72, U).join(',')).join(' ');
  const showAI = L(f, dur * 0.4, dur * 0.5, 0, 1);
  const pa = ((f % 70) / 70);
  const head: [number, number] = [PP[0] + 540, PP[1] + 1000 - 230];
  return (
    <AbsoluteFill>
      <Sky mood={mood} f={f} />
      <svg {...svgProps}>
        <Defs />
        <Cam f={f} dur={dur} a={[1.1, 40, -20]} b={[1.0, 0, 0]}>
          <Wrap>
            <Room mood={mood} />
            <Desk />
            <Laptop glow={0.5 + 0.5 * showAI}>
              {[0, 1, 2, 3].map((i) => (<LN key={i} y={LY + 0.01} xa={-0.5} xb={-0.5 + 1.0 * showAI * (1 - i * 0.12)} z={2.7 - i * 0.2} c="#fff" w={5} />))}
            </Laptop>
            <Cube x={0.9} y={0.1} z={1.68} w={1.0} d={0.8} h={0.03} c="#ffffff" u={U} />
            <polyline points={wr} fill="none" stroke="#6a5fc4" strokeWidth={3.5} strokeLinecap="round" strokeDasharray={400} strokeDashoffset={400 * (1 - prog)} />
            <Person x={PP[0]} y={PP[1]} c="#b9a3ff" s={1.35} sit bob={Math.sin(f * 0.1) * 2} />
          </Wrap>
          <Bulb x={head[0]} y={head[1] - 40} s={1.0} on={L(f, 20, 60, 0, 1)} />
          {showAI > 0.2 && (
            <g opacity={showAI}>
              <circle cx={head[0] + (LAP[0] - head[0]) * pa} cy={head[1] + 60 + (LAP[1] - head[1] - 60) * pa} r={14} fill={mix('#ffb36b', '#ffb36b', 1)} />
              <circle cx={LAP[0] + (head[0] - LAP[0]) * pa} cy={LAP[1] - 40 + (head[1] + 90 - LAP[1]) * pa} r={14} fill="#8ec5ff" />
              <Sparkle x={LAP[0]} y={LAP[1] - 190} r={30} c="#fff" rot={f * 2} />
            </g>
          )}
        </Cam>
        <Pill x={290} y={300} t="MANUSIA BERPIKIR" bg="#ff9f4a" fs={30} />
        <Pill x={540} y={300} t="+" bg="#ffffff" fg="#2c2a5a" fs={40} />
        <Pill x={800} y={300} t="AI MEMBANTU" bg="#6aa8f5" fs={30} />
      </svg>
    </AbsoluteFill>
  );
};

// ---------- 6. BERPIKIR KRITIS ----------
export const S6: React.FC<SP> = ({dur, from}) => {
  const f = useCurrentFrame();
  const g = f + from;
  const st = [0, BEAT6[0] * FPS, BEAT6[1] * FPS, 1e9];
  const labels = [['Pikirkan dulu', 'sebelum bertanya'], ['AI membantu', 'menjelaskan materi'], ['Periksa kembali', 'buku & sumber tepercaya']];
  const x0 = 90, cy = [420, 830, 1240];
  return (
    <AbsoluteFill>
      <Sky mood={0.75} f={f} />
      <svg {...svgProps}>
        <Defs />
        <Cam f={f} dur={dur} a={[1, 0, 0]} b={[1.03, 0, 0]}>
          {[0, 1, 2].map((i) => {
            const a = L(g, st[i], st[i] + 12, 0, 1) * (i < 2 ? 1 - L(g, st[i + 1] - 12, st[i + 1], 0, 1) : 1);
            const y = cy[i];
            return (
              <g key={i} opacity={0.55 + 0.45 * a} transform={`translate(540,${y}) scale(${0.95 + 0.05 * a}) translate(-540,${-y})`}>
                <rect x={x0} y={y - 175} width={900} height={350} rx={48} fill="#fff" opacity={0.88} />
                <circle cx={x0 + 60} cy={y - 115} r={34} fill={['#ffb36b', '#8ec5ff', '#9be3b0'][i]} />
                <text x={x0 + 60} y={y - 102} textAnchor="middle" fontFamily={fontFamily} fontWeight={800} fontSize={40} fill="#fff">{i + 1}</text>
                <text x={x0 + 480} y={y - 20} fontFamily={fontFamily} fontWeight={800} fontSize={50} fill="#2c2a5a">{labels[i][0]}</text>
                <text x={x0 + 480} y={y + 40} fontFamily={fontFamily} fontWeight={600} fontSize={32} fill="#6a5fc4">{labels[i][1]}</text>
                {i === 0 && (<g><Person x={x0 + 170} y={y + 150} c="#b9a3ff" s={1.0} bob={Math.sin(f * 0.1) * 2} /><Bulb x={x0 + 290} y={y - 70} s={1} on={0.3 + 0.7 * a} /></g>)}
                {i === 1 && (
                  <g>
                    <rect x={x0 + 90} y={y - 100} width={240} height={160} rx={14} fill="#2c2a5a" />
                    <rect x={x0 + 102} y={y - 88} width={216} height={136} rx={8} fill="#8ec5ff" />
                    {[0, 1, 2, 3].map((k) => (<rect key={k} x={x0 + 116} y={y - 74 + k * 28} width={150 - k * 14} height={10} rx={5} fill="#fff" />))}
                    <rect x={x0 + 120} y={y + 60} width={140} height={14} rx={7} fill="#cfd6f5" />
                    <Sparkle x={x0 + 350} y={y - 100} r={34} c="#ffb36b" rot={f * 2} />
                  </g>
                )}
                {i === 2 && (
                  <g>
                    <polygon points={`${x0 + 80},${y - 50} ${x0 + 190},${y - 40} ${x0 + 190},${y + 70} ${x0 + 80},${y + 58}`} fill="#fff4e0" stroke="#d9c7a6" strokeWidth={4} />
                    <polygon points={`${x0 + 190},${y - 40} ${x0 + 300},${y - 50} ${x0 + 300},${y + 58} ${x0 + 190},${y + 70}`} fill="#fffaf0" stroke="#d9c7a6" strokeWidth={4} />
                    <Magnifier x={x0 + 230 + Math.sin(f * 0.08) * 12} y={y - 5} s={1.2} />
                    <circle cx={x0 + 340} cy={y + 80} r={20} fill="#9be3b0" />
                    <polyline points={`${x0 + 330},${y + 80} ${x0 + 338},${y + 89} ${x0 + 352},${y + 70}`} stroke="#fff" strokeWidth={5} fill="none" strokeLinecap="round" />
                  </g>
                )}
              </g>
            );
          })}
        </Cam>
      </svg>
    </AbsoluteFill>
  );
};

// ---------- 7. ENDING ----------
export const S7: React.FC<SP> = ({dur, from}) => {
  const f = useCurrentFrame();
  const g = f + from;
  const u = 28;
  const ts = T_TITLE * FPS, tc = T_CLOSE * FPS;
  const folks = [[8, 12, '#b9a3ff'], [16, 12, '#ffb36b'], [12, 20, '#8ec5ff'], [20, 20, '#d9ccff'], [8, 24, '#ffb36b'], [24, 12, '#b9a3ff']] as const;
  const ov = L(g, ts - 10, ts + 20, 0, 0.55);
  const row = (t: string, y: number, c: string, start: number, fs: number) => (
    <text x={540} y={y - L(g, start, start + 18, -30, 0)} textAnchor="middle" fontFamily={fontFamily} fontWeight={800} fontSize={fs} fill={c} opacity={L(g, start, start + 18, 0, 1)} style={{filter: 'drop-shadow(0 6px 18px rgba(20,10,60,.6))'}}>{t}</text>
  );
  const titleOp = 1 - L(g, tc - 10, tc + 4, 0, 1);
  return (
    <AbsoluteFill>
      <Sky mood={L(f, 0, 60, 0.5, 1)} f={f} />
      <svg {...svgProps}>
        <Defs />
        <Cam f={f} dur={Math.min(dur, tc - from)} a={[1.55, 0, -90]} b={[0.85, 0, 0]}>
          <g transform="translate(540,860)"><City f={f} mood={L(f, 0, 60, 0.6, 1)} u={u} /></g>
          {folks.map(([x, y, c], i) => {
            const p = cityPt(x, y, 0.05, u);
            const px = 540 + p[0], py = 860 + p[1];
            return (
              <g key={i}>
                <Person x={px} y={py} c={c} s={0.42} bob={Math.sin(f * 0.1 + i) * 1.5} dev={i % 2 === 0} />
                <Bulb x={px} y={py - 85} s={0.4} on={0.6 + 0.4 * Math.sin(f * 0.1 + i)} />
              </g>
            );
          })}
          {[0, 1, 2, 3, 4].map((k) => (<Sparkle key={k} x={140 + k * 200} y={380 + (k % 2) * 140 - Math.sin(f * 0.05 + k) * 12} r={16} c="#fff" op={0.8} rot={f * 2} />))}
        </Cam>
        <rect width={1080} height={1920} fill="#1a1550" opacity={ov} />
        <g opacity={titleOp}>
          {row('AI UNTUK MEMBANTU,', 560, '#fff', ts, 66)}
          {row('BUKAN MENGGANTIKAN', 650, C_OR, ts + 12, 66)}
          {row('BERPIKIR.', 740, C_OR, ts + 24, 66)}
        </g>
        {row('Gunakan AI dengan bijak.', 640, '#fff', tc, 52)}
        {row('Tetap berpikir, tetap belajar.', 720, C_OR, tc + 12, 52)}
      </svg>
    </AbsoluteFill>
  );
};
const C_OR = '#ffb36b';
