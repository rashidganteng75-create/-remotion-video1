// ===== EDIT DI SINI bila sinkronisasi kurang pas (detik, relatif ke awal tiap file audio) =====
export const FPS = 30;
export const OFF2 = 16.0853; // durasi file 1 (AUD-20261121-WA0011_1.m4a) -> file 2 mulai di sini
export const V2 = 33.472; // durasi file 2 (voice_over_2.m4a)
export const END_SEC = OFF2 + V2 + 0.4;
export const DURATION = Math.ceil(END_SEC * FPS);

export type Phrase = {a: number; b: number; t: string};
const p1 = (a: number, b: number, t: string): Phrase => ({a, b, t});
const p2 = (a: number, b: number, t: string): Phrase => ({a: a + OFF2, b: b + OFF2, t});

export const PHRASES: Phrase[] = [
  // file 1 (jeda terdeteksi di 11.2-11.8, 12.8-13.4, 15.4-15.8)
  p1(0.65, 4.0, 'Apakah menggunakan AI itu akan selalu mempermudah terus menerus?'),
  p1(4.2, 7.4, 'Ketika setiap persoalan selalu diserahkan kepada AI,'),
  p1(7.4, 11.24, 'kita perlahan kehilangan kesempatan untuk berpikir, mencoba, dan belajar dari kesalahan.'),
  p1(11.76, 12.83, 'Jawaban mungkin didapat,'),
  p1(13.43, 15.41, 'tetapi pemahaman belum tentu terbentuk.'),
  // file 2 (jeda terdeteksi di 2.4, 4.9, 7.4, 9.4, 11.8, 15.2, 20.7, 22.8, 23.6, 24.9, 26.6, 29.0, 31.0, 32.3)
  p2(0.1, 2.4, 'Bukan berarti kita harus berhenti menggunakan AI.'),
  p2(2.84, 4.88, 'Gunakan teknologi ini sebagai alat bantu,'),
  p2(5.35, 7.4, 'bukan sebagai pengganti kemampuan kita.'),
  p2(7.92, 9.35, 'Cobalah berpikir terlebih dahulu,'),
  p2(9.66, 11.82, 'gunakan AI untuk memahami,'),
  p2(12.14, 15.2, 'dan jangan lupa memeriksa kembali setiap informasi yang diberikan.'),
  p2(15.79, 20.7, 'Karena masa depan bukan hanya tentang siapa yang paling cepat mendapatkan jawaban,'),
  p2(21.15, 22.82, 'tetapi siapa yang mampu berpikir,'),
  p2(23.19, 23.64, 'memahami,'),
  p2(23.89, 24.89, 'dan mengambil keputusan.'),
  p2(25.43, 26.63, 'AI untuk membantu,'),
  p2(27.08, 28.98, 'bukan menggantikan berpikir.'),
  p2(29.55, 31.02, 'Gunakan AI dengan bijak.'),
  p2(31.6, 32.3, 'Tetap berpikir,'),
  p2(32.67, 33.45, 'tetap belajar.'),
];

// batas adegan 1..7 (detik, global)
export const BOUNDS = [0, 4.1, 7.4, 11.5, OFF2, OFF2 + 7.65, OFF2 + 15.5, END_SEC];
export const BEAT6 = [OFF2 + 9.5, OFF2 + 11.98]; // pergantian 3 visual di adegan 6
export const T_TITLE = OFF2 + 25.2; // teks utama
export const T_CLOSE = OFF2 + 29.4; // teks penutup
