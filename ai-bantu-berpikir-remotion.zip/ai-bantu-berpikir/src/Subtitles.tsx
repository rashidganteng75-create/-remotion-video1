import React from 'react';
import {useCurrentFrame, spring, useVideoConfig} from 'remotion';
import {PHRASES, FPS} from './timing';
import {fontFamily} from './lib';

type W = {w: string; a: number; b: number};
type Ch = {a: number; b: number; words: W[]};

const CHUNKS: Ch[] = (() => {
  const out: Ch[] = [];
  for (const p of PHRASES) {
    const ws = p.t.split(/\s+/);
    const wt = ws.map((w) => w.length + 1.5);
    const sum = wt.reduce((x, y) => x + y, 0);
    let c = p.a;
    const timed: W[] = ws.map((w, i) => {
      const d = ((p.b - p.a) * wt[i]) / sum;
      const r = {w, a: c, b: c + d};
      c += d;
      return r;
    });
    const g = Math.ceil(ws.length / 4);
    const base = Math.floor(ws.length / g);
    let rem = ws.length - base * g;
    let idx = 0;
    for (let k = 0; k < g; k++) {
      const n = base + (rem-- > 0 ? 1 : 0);
      const part = timed.slice(idx, idx + n);
      idx += n;
      out.push({a: part[0].a, b: part[part.length - 1].b, words: part});
    }
  }
  for (let i = 0; i < out.length - 1; i++) out[i].b = Math.min(out[i + 1].a, out[i].b + 0.25);
  out[out.length - 1].b += 0.35;
  return out;
})();

export const Subtitles: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / FPS;
  const ch = CHUNKS.find((c) => t >= c.a - 0.03 && t < c.b);
  if (!ch) return null;
  const pop = spring({frame: frame - Math.round(ch.a * FPS), fps, config: {damping: 14, stiffness: 180}, durationInFrames: 14});
  return (
    <div style={{position: 'absolute', left: 60, right: 60, top: 1400, height: 250, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.86 + 0.14 * pop})`, opacity: Math.min(1, pop * 1.5)}}>
      <div style={{textAlign: 'center', fontFamily, fontWeight: 800, fontSize: 80, lineHeight: 1.18, color: '#fff', WebkitTextStroke: '10px #2c2a5a', paintOrder: 'stroke fill', textShadow: '0 8px 24px rgba(30,20,80,.55)'}}>
        {ch.words.map((w, i) => {
          const active = t >= w.a && t < w.b;
          return (
            <span key={i} style={{color: active ? '#ffb36b' : '#fff', display: 'inline-block', margin: '0 12px', transform: active ? 'scale(1.1)' : 'scale(1)'}}>
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};
