import React from 'react';
import {AbsoluteFill, Easing, random} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Poppins';

export const {fontFamily} = loadFont('normal', {weights: ['600', '800'], subsets: ['latin']});

export const C = {orange: '#ffb36b', blue: '#8ec5ff', purple: '#b9a3ff', ink: '#2c2a5a'};
const rgb = (hex: string) => {
  const n = parseInt(hex.slice(1), 16);
  return [n >> 16, (n >> 8) & 255, n & 255];
};
export const mix = (a: string, b: string, t: number) => {
  const A = rgb(a), B = rgb(b), k = Math.max(0, Math.min(1, t));
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * k).toString(16).padStart(2, '0')).join('');
};
export const shade = (hex: string, k: number) => (k < 0 ? mix(hex, '#000000', -k) : mix(hex, '#ffffff', k));
export const L = (f: number, a: number, b: number, x: number, y: number, e = Easing.inOut(Easing.cubic)) => {
  const t = Math.min(1, Math.max(0, (f - a) / (b - a)));
  return x + (y - x) * e(t);
};
export const pt = (x: number, y: number, z: number, u: number): [number, number] => [(x - y) * 0.866 * u, (x + y) * 0.5 * u - z * u];
export const Q = (pts: number[][], u: number) => pts.map((p) => pt(p[0], p[1], p[2], u).join(',')).join(' ');

export const Defs = () => (
  <defs>
    <radialGradient id="glowY"><stop offset="0" stopColor="#ffe9a8" stopOpacity="0.95" /><stop offset="1" stopColor="#ffe9a8" stopOpacity="0" /></radialGradient>
    <radialGradient id="glowB"><stop offset="0" stopColor="#9fd0ff" stopOpacity="0.95" /><stop offset="1" stopColor="#9fd0ff" stopOpacity="0" /></radialGradient>
    <radialGradient id="glowO"><stop offset="0" stopColor="#ffb36b" stopOpacity="0.9" /><stop offset="1" stopColor="#ffb36b" stopOpacity="0" /></radialGradient>
  </defs>
);

export const Sky: React.FC<{mood: number; f: number}> = ({mood, f}) => {
  const stars = React.useMemo(() => Array.from({length: 80}, (_, i) => ({x: random(`sx${i}`) * 1080, y: random(`sy${i}`) * 1200, r: 1 + random(`sr${i}`) * 2.2, p: random(`sp${i}`) * 6})), []);
  return (
    <AbsoluteFill style={{background: `linear-gradient(180deg, ${mix('#14173f', '#bfe0ff', mood)} 0%, ${mix('#4a3f8f', '#f3e8ff', mood)} 60%, ${mix('#2b2e6e', '#ffeede', mood)} 100%)`}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        {stars.map((s, i) => (<circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#fff" opacity={(1 - mood) * (0.45 + 0.45 * Math.sin(f * 0.08 + s.p))} />))}
        <circle cx={880} cy={230} r={60} fill={mix('#fff6dc', '#fff0c8', mood)} opacity={0.9} />
        {[0, 1, 2].map((k) => (<ellipse key={k} cx={((f * 0.35 + k * 420) % 1500) - 200} cy={200 + k * 170} rx={150} ry={36} fill="#fff" opacity={mood * 0.7} />))}
      </svg>
    </AbsoluteFill>
  );
};

export const Cam: React.FC<{f: number; dur: number; a: number[]; b: number[]; children: React.ReactNode}> = ({f, dur, a, b, children}) => {
  const t = Easing.inOut(Easing.sin)(Math.min(1, Math.max(0, f / dur)));
  const s = a[0] + (b[0] - a[0]) * t, x = a[1] + (b[1] - a[1]) * t, y = a[2] + (b[2] - a[2]) * t;
  return <g transform={`translate(540,960) scale(${s}) translate(${-540 + x},${-960 + y})`}>{children}</g>;
};

export const Cube: React.FC<{x: number; y: number; z?: number; w: number; d: number; h: number; c: string; u?: number; op?: number}> = ({x, y, z = 0, w, d, h, c, u = 40, op = 1}) => (
  <g opacity={op}>
    <polygon points={Q([[x, y + d, z], [x + w, y + d, z], [x + w, y + d, z + h], [x, y + d, z + h]], u)} fill={shade(c, -0.14)} />
    <polygon points={Q([[x + w, y, z], [x + w, y + d, z], [x + w, y + d, z + h], [x + w, y, z + h]], u)} fill={shade(c, -0.32)} />
    <polygon points={Q([[x, y, z + h], [x + w, y, z + h], [x + w, y + d, z + h], [x, y + d, z + h]], u)} fill={shade(c, 0.16)} />
  </g>
);

export const Person: React.FC<{x: number; y: number; c: string; s?: number; sit?: boolean; dev?: boolean; bob?: number; rot?: number; hair?: string}> = ({x, y, c, s = 1, sit = false, dev = false, bob = 0, rot = 0, hair = '#5b4b8a'}) => {
  const top = sit ? -86 : -122;
  return (
    <g transform={`translate(${x},${y + bob}) scale(${s})`}>
      <ellipse cx={0} cy={2} rx={30} ry={10} fill="#1a1c4a" opacity={0.22} />
      {sit ? (
        <rect x={-22} y={-30} width={44} height={22} rx={10} fill={shade(c, -0.35)} />
      ) : (
        <g>
          <rect x={-15} y={-52} width={12} height={52} rx={6} fill={shade(c, -0.35)} />
          <rect x={3} y={-52} width={12} height={52} rx={6} fill={shade(c, -0.35)} />
        </g>
      )}
      <rect x={-21} y={top} width={42} height={sit ? 62 : 76} rx={18} fill={c} />
      <g transform={`rotate(${rot} 0 ${top - 4})`}>
        <circle cx={0} cy={top - 20} r={19} fill="#ffe1d0" />
        <path d={`M-19 ${top - 26} A19 19 0 0 1 19 ${top - 26} Z`} fill={hair} />
      </g>
      {dev && (
        <g>
          <circle cx={0} cy={top + 34} r={46} fill="url(#glowB)" />
          <rect x={-20} y={top + 22} width={40} height={26} rx={4} fill="#dfe8ff" />
          <rect x={-16} y={top + 26} width={32} height={18} rx={3} fill="#8ec5ff" />
        </g>
      )}
    </g>
  );
};

export const Bulb: React.FC<{x: number; y: number; s?: number; on?: number}> = ({x, y, s = 1, on = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    {on > 0.05 && <circle r={110} fill="url(#glowY)" opacity={on} />}
    <path d="M0,-34 C-26,-34 -34,-8 -20,12 C-14,20 -12,26 -12,34 L12,34 C12,26 14,20 20,12 C34,-8 26,-34 0,-34Z" fill={mix('#d9d9ec', '#ffe08a', on)} stroke="#fff" strokeWidth={3} />
    <rect x={-11} y={36} width={22} height={7} rx={3} fill="#b9a3ff" />
    <rect x={-8} y={45} width={16} height={6} rx={3} fill="#9b88f0" />
  </g>
);

export const Sparkle: React.FC<{x: number; y: number; r: number; c?: string; op?: number; rot?: number}> = ({x, y, r, c = '#fff', op = 1, rot = 0}) => (
  <path transform={`translate(${x},${y}) rotate(${rot})`} d={`M0 ${-r} L${r * 0.25} ${-r * 0.25} L${r} 0 L${r * 0.25} ${r * 0.25} L0 ${r} L${-r * 0.25} ${r * 0.25} L${-r} 0 L${-r * 0.25} ${-r * 0.25}Z`} fill={c} opacity={op} />
);

export const Magnifier: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <circle r={34} fill="#cfe6ff" fillOpacity={0.5} stroke="#fff" strokeWidth={8} />
    <line x1={24} y1={24} x2={56} y2={56} stroke="#ffb36b" strokeWidth={12} strokeLinecap="round" />
  </g>
);

export const Pill: React.FC<{x: number; y: number; t: string; bg: string; fg?: string; op?: number; s?: number; fs?: number}> = ({x, y, t, bg, fg = '#fff', op = 1, s = 1, fs = 34}) => {
  const w = t.length * fs * 0.62 + 56;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`} opacity={op}>
      <rect x={-w / 2} y={-34} width={w} height={68} rx={34} fill={bg} />
      <text textAnchor="middle" y={12} fontFamily={fontFamily} fontWeight={800} fontSize={fs} fill={fg}>{t}</text>
    </g>
  );
};

export const TaskCard: React.FC<{x: number; y: number; s?: number; op?: number; rot?: number}> = ({x, y, s = 1, op = 1, rot = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`} opacity={op}>
    <rect x={-60} y={-38} width={120} height={76} rx={14} fill="#fff" />
    <rect x={-44} y={-22} width={64} height={8} rx={4} fill="#b9a3ff" />
    <rect x={-44} y={-6} width={88} height={8} rx={4} fill="#cfe6ff" />
    <rect x={-44} y={10} width={50} height={8} rx={4} fill="#cfe6ff" />
    <text x={38} y={-12} fontFamily={fontFamily} fontWeight={800} fontSize={30} fill="#ffb36b">?</text>
  </g>
);

// ---------- Kota mini ----------
type B = {x: number; y: number; w: number; d: number; h: number; c: string; k: 'tower' | 'house' | 'school'};
const PAL = ['#c9defc', '#d9ccff', '#f3eaff', '#bcd7ff', '#e6dcff', '#ffffff', '#ffd9b8'];
const BUILDINGS: B[] = (() => {
  const out: B[] = [];
  for (let i = 0; i < 7; i++)
    for (let j = 0; j < 7; j++) {
      const r = random(`b${i}-${j}`);
      const x = i * 4 + 0.7, y = j * 4 + 0.7;
      if (i === 3 && j === 3) { out.push({x, y, w: 2.8, d: 2.8, h: 3.2, c: '#ffe3c2', k: 'school'}); continue; }
      const k = r > 0.45 ? 'tower' : 'house';
      out.push({x, y, w: 2.6, d: 2.6, h: k === 'tower' ? 3 + random(`h${i}-${j}`) * 7 : 1.6 + r * 0.8, c: PAL[Math.floor(random(`c${i}-${j}`) * PAL.length)], k});
    }
  return out.sort((a, b) => a.x + a.y - (b.x + b.y));
})();

const O = 14;
export const cityPt = (x: number, y: number, z: number, u: number) => pt(x - O, y - O, z, u);

const Windows: React.FC<{b: B; u: number; mood: number}> = ({b, u, mood}) => {
  const rows = b.k === 'house' ? 1 : Math.max(1, Math.floor(b.h / 1.3));
  const cols = 2;
  const els: React.ReactNode[] = [];
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const lit = random(`w${b.x}${b.y}${r}${c}`) > 0.4;
      const col = lit ? mix('#ffd9a0', '#cfe6ff', mood) : mix('#2a2d6a', '#b9c9f5', mood);
      const z0 = (r + 0.3) * (b.h / rows), hh = 0.45 * (b.h / rows);
      const wx = b.x - O + (c + 0.25) * (b.w / cols), ww = 0.5 * (b.w / cols);
      const wy = b.y - O + (c + 0.25) * (b.d / cols), wd = 0.5 * (b.d / cols);
      els.push(<polygon key={`l${r}${c}`} points={Q([[wx, b.y - O + b.d, z0], [wx + ww, b.y - O + b.d, z0], [wx + ww, b.y - O + b.d, z0 + hh], [wx, b.y - O + b.d, z0 + hh]], u)} fill={col} />);
      els.push(<polygon key={`r${r}${c}`} points={Q([[b.x - O + b.w, wy, z0], [b.x - O + b.w, wy + wd, z0], [b.x - O + b.w, wy + wd, z0 + hh], [b.x - O + b.w, wy, z0 + hh]], u)} fill={col} opacity={0.85} />);
    }
  return <g>{els}</g>;
};

export const City: React.FC<{f: number; mood: number; u?: number}> = ({f, mood, u = 28}) => (
  <g>
    <Cube x={-O} y={-O} z={-0.6} w={28} d={28} h={0.6} c={mix('#2d3170', '#d9d4ff', mood)} u={u} />
    {Array.from({length: 49}).map((_, n) => (
      <Cube key={n} x={(n % 7) * 4 - O + 0.35} y={Math.floor(n / 7) * 4 - O + 0.35} z={0} w={3.3} d={3.3} h={0.05} c={mix('#4a4f96', '#f4efff', mood)} u={u} />
    ))}
    {BUILDINGS.map((b, i) => (
      <g key={i}>
        <Cube x={b.x - O} y={b.y - O} w={b.w} d={b.d} h={b.h} c={b.c} u={u} />
        {b.k === 'house' && <Cube x={b.x - O + 0.4} y={b.y - O + 0.4} z={b.h} w={b.w - 0.8} d={b.d - 0.8} h={0.5} c="#ffb9a0" u={u} />}
        {b.k === 'school' && (
          <g>
            <Cube x={b.x - O + 0.9} y={b.y - O + 0.9} z={b.h} w={1} d={1} h={0.9} c="#ffd0a0" u={u} />
            <polyline points={Q([[b.x - O + 1.4, b.y - O + 1.4, b.h + 0.9], [b.x - O + 1.4, b.y - O + 1.4, b.h + 2.4]], u)} stroke="#fff" strokeWidth={3} />
            <polygon points={Q([[b.x - O + 1.4, b.y - O + 1.4, b.h + 2.4], [b.x - O + 2.2, b.y - O + 1.4, b.h + 2.2], [b.x - O + 1.4, b.y - O + 1.4, b.h + 2.0]], u)} fill="#ffb36b" />
          </g>
        )}
        <Windows b={b} u={u} mood={mood} />
      </g>
    ))}
    {Array.from({length: 8}).map((_, k) => {
      const x = ((f * 0.07 * (k % 2 ? 1 : -1) + k * 5.3) % 28 + 28) % 28;
      return <Cube key={k} x={x - O} y={(k % 6 + 1) * 4 - O - 0.15} z={0.05} w={0.6} d={0.35} h={0.3} c={k % 3 === 0 ? '#ffb36b' : '#ffffff'} u={u} />;
    })}
  </g>
);

export const FadeIn: React.FC<{frame: number; first: boolean; children: React.ReactNode}> = ({frame, first, children}) => (
  <AbsoluteFill style={{opacity: first ? 1 : L(frame, 0, 12, 0, 1)}}>{children}</AbsoluteFill>
);
