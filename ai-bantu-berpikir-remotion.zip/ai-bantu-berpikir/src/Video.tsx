import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {BOUNDS, DURATION, FPS, OFF2} from './timing';
import {S1, S2, S3, S4, S5, S6, S7, SP} from './scenes';
import {FadeIn} from './lib';
import {Subtitles} from './Subtitles';

const OV = 12;
const COMPS: React.FC<SP>[] = [S1, S2, S3, S4, S5, S6, S7];

const Scene: React.FC<{i: number}> = ({i}) => {
  const a = Math.round(BOUNDS[i] * FPS), b = i === 6 ? DURATION : Math.round(BOUNDS[i + 1] * FPS);
  const from = Math.max(0, a - OV);
  const dur = Math.min(b - from + OV, DURATION - from);
  const Comp = COMPS[i];
  return (
    <Sequence from={from} durationInFrames={dur}>
      <SceneInner first={from === 0}><Comp dur={dur} from={from} /></SceneInner>
    </Sequence>
  );
};
const SceneInner: React.FC<{first: boolean; children: React.ReactNode}> = ({first, children}) => {
  const f = useCurrentFrame();
  return <FadeIn frame={f} first={first}>{children}</FadeIn>;
};

export const Video: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#14173f'}}>
    {COMPS.map((_, i) => (<Scene key={i} i={i} />))}
    <Subtitles />
    <Sequence from={0}><Audio src={staticFile('vo1.m4a')} /></Sequence>
    <Sequence from={Math.round(OFF2 * FPS)}><Audio src={staticFile('vo2.m4a')} /></Sequence>
    <Audio src={staticFile('bgm.mp3')} volume={(f) => interpolate(f, [0, 45, DURATION - 60, DURATION], [0, 0.1, 0.1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
  </AbsoluteFill>
);
