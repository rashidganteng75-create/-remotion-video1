# AI untuk Membantu, Bukan Menggantikan Berpikir (Remotion, 1080x1920, 30 FPS)

```
npm install
npm run studio     # pratinjau
npm run render     # hasil: out/ai-bantu-berpikir.mp4 (H.264)
```
- Audio: public/vo1.m4a (AUD-20261121-WA0011_1) lalu public/vo2.m4a (voice_over_2); bgm.mp3 = musik latar sintesis (volume 10%).
- Sinkronisasi subtitle/adegan ada di src/timing.ts (detik). Ubah angka di sana jika ada kata yang meleset.
- Font Poppins diunduh otomatis saat render (butuh internet).
